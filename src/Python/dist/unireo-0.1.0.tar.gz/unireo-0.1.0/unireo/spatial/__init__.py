"""
Import all error code from following modules
"""

from .depth import *
