"""
用于存放共享变量
\n
This module is used to store shared variables
"""
latest_key: int = 0
